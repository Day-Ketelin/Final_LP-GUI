package view;

import model.*;
import controller.*;

public class Negocio {
    public Negocio() {
    }

    public static void main(String[] args) {
    }
}
