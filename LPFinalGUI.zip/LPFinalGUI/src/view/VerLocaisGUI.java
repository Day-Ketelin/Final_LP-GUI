package view;
import model.*;

import javax.swing.*;
import java.util.ArrayList;

public class VerLocaisGUI extends JFrame {

    public VerLocaisGUI() {
    }

    public static void main(String[] args) {
        System.out.println("Alugue e Use!\n");
        ArrayList<Local> local = new ArrayList();
        local.add(new Salas(2222, "Prédio 1 - Rua das Abelhas nº 2000 - Bairro Colméia BH/MG", 25));
        local.add(new Auditorios(1111, "Auditório A - Rua das Abelhas nº 2000 - Bairro Colméia BH/MG", 120));
        local.add(new SalaoFestas(333, "Alegria & Festa - Rua das Abelhas nº 2010 - Bairro Colméia BH/MG", 235));
        local.add(new Salas(21, "Prédio 1 - Rua das Abelhas nº 2000 - Bairro Colméia BH/MG", 15));
    }
}
