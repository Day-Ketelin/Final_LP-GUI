import model.Local;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Main {

//    public class CadastraLocal extends JFrame {
//        private JPanel painel = new JPanel();
//        private JButton jButtonCadastrar = new JButton("Cadastrar local");
//        private JButton jButtonAtualizar = new JButton("Atualizar local");
//        private static ArrayList<Local> local = new ArrayList();
//
//        public CadastraLocal() {
//            cadastrar();
//            this.setTitle("** Alugue & Use **");
//            this.setSize(250, 250);
//            this.painel.setLayout(new FlowLayout(1, 50, 40));
//            this.painel.setBackground(new Color(255, 255, 255));
//            this.jButtonCadastrar.addActionListener(new ActionListener() {
//                public void actionPerformed(ActionEvent e) {
//                    CadastraLocal.cadastrar();
//                }
//            });
//            this.painel.add(this.jButtonCadastrar);
//            this.jButtonAtualizar.addActionListener(new ActionListener() {
//                public void actionPerformed(ActionEvent e) {
//                    CadastraLocal.atualizar();
//                }
//            });
//            this.getContentPane().add(this.painel);
//            this.setLocationRelativeTo((Component)null);
//            this.setDefaultCloseOperation(3);
//            this.setVisible(true);
//        }
//
//        private static void cadastrar() {
//            JOptionPane.showInputDialog((Component)null, "Insira os dados do local a ser cadastrado");
//            JOptionPane.showMessageDialog((Component)null, "Insira os dados do local a ser cadastrado");
//        }
//
//        private static void atualizar() {
//            JOptionPane.showMessageDialog((Component)null, "Insira os dados do local a ser cadastrado");
//        }
//
//        public static void main(String[] args) {
//            new CadastraLocal();
//        }
//    }
//
//
//    public static void main(String[] args) {
//        System.out.println("Hello world!");
//    }
}