//package model;
//
//public class SalaoFestas extends Local {
//    private int lugares;
//
//    public SalaoFestas(int id, String local, int lugares) {
//        super(id, local);
//        this.lugares = lugares;
//    }
//
//    public int getLugares() {
//        return this.lugares;
//    }
//
//    public void setLugares(int lugares) {
//        this.lugares = lugares;
//    }
//
//    public String toString() {
//        String var10000 = super.toString();
//        return "Salão de Festas - " + var10000 + ", Número de cadeiras: " + this.lugares;
//    }
//}
