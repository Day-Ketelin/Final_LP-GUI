package model;

public interface Produto {

}
