package model;

//public class Auditorios extends Local {
//    private int tempo;
//
//    public Auditorios(int id, String local, int tempo) {
//        super(id, local);
//        this.tempo = tempo;
//    }
//
//    public int getTempo() {
//        return this.tempo;
//    }
//
//    public void setTempo(int duracao) {
//        this.tempo = this.tempo;
//    }
//
//    public String toString() {
//        String var10000 = super.toString();
//        return "Auditório - " + var10000 + ", Duração: " + this.tempo + " minutos";
//    }
//}
