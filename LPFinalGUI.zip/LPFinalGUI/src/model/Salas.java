//package model;
//
//public class Salas extends Local {
//    private int sala;
//
//    public Salas(int id, String local, int sala) {
//        super(id, local);
//        this.sala = sala;
//    }
//
//    public int getSala() {
//        return this.sala;
//    }
//
//    public void setSala(int edicao) {
//        this.sala = this.sala;
//    }
//
//    public String toString() {
//        String var10000 = super.toString();
//        return "Local - " + var10000 + ", Sala: " + this.sala;
//    }
//}
